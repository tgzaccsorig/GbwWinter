package ru.goodbadworld.winter;

import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.Random;

public final class GoodBadWorldWinter extends JavaPlugin implements Listener {
    private final Random random = new Random();
    private BukkitTask snowTask;
    private boolean enabled;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(this, this);
        enabled = getConfig().getBoolean("winter.enabled", true);
        if (enabled) startWinter();
        getLogger().info("GoodBadWorld Winter Edition enabled.");
    }

    @Override
    public void onDisable() {
        stopSnowTask();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        String url = getConfig().getString("resource-pack.url", "").trim();
        if (url.isEmpty()) return;
        String sha1 = getConfig().getString("resource-pack.sha1", "").trim();
        try {
            if (sha1.isEmpty()) event.getPlayer().setResourcePack(url);
            else event.getPlayer().setResourcePack(url, hexToBytes(sha1), false);
        } catch (IllegalArgumentException ex) {
            getLogger().warning("Некорректный SHA-1 ресурс-пака в config.yml: " + ex.getMessage());
        }
    }

    private byte[] hexToBytes(String value) {
        if (value.length() != 40) throw new IllegalArgumentException("SHA-1 должен содержать 40 символов");
        byte[] result = new byte[20];
        for (int i = 0; i < result.length; i++) {
            int index = i * 2;
            result[i] = (byte) Integer.parseInt(value.substring(index, index + 2), 16);
        }
        return result;
    }

    private void startWinter() {
        enabled = true;
        for (World world : Bukkit.getWorlds()) applyWinterWeather(world);
        stopSnowTask();
        long interval = Math.max(2L, getConfig().getLong("snow.interval-ticks", 5L));
        snowTask = Bukkit.getScheduler().runTaskTimer(this, this::spawnSnow, 1L, interval);
    }

    private void applyWinterWeather(World world) {
        if (getConfig().getBoolean("winter.force-snow-weather", true)) {
            world.setStorm(true);
            world.setThundering(false);
            world.setWeatherDuration(20 * 60 * 60);
            world.setThunderDuration(0);
        }
        if (getConfig().getBoolean("winter.freeze-time", false)) {
            world.setTime(getConfig().getLong("winter.time", 18000L));
            world.setGameRule(org.bukkit.GameRule.DO_DAYLIGHT_CYCLE, false);
        }
    }

    private void spawnSnow() {
        if (!enabled) return;
        int count = Math.max(1, getConfig().getInt("snow.particles-per-player", 18));
        double radius = Math.max(2.0, getConfig().getDouble("snow.radius", 9.0));
        for (Player player : Bukkit.getOnlinePlayers()) {
            World world = player.getWorld();
            for (int i = 0; i < count; i++) {
                double x = player.getLocation().getX() + (random.nextDouble() * 2 - 1) * radius;
                double z = player.getLocation().getZ() + (random.nextDouble() * 2 - 1) * radius;
                double y = player.getLocation().getY() + 4 + random.nextDouble() * 9;
                world.spawnParticle(Particle.SNOWFLAKE, x, y, z, 1, 0.12, 0.18, 0.12, 0.005);
            }
        }
    }

    private void stopSnowTask() {
        if (snowTask != null) {
            snowTask.cancel();
            snowTask = null;
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("gbwinter.admin")) {
            sender.sendMessage("§cНедостаточно прав.");
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("status")) {
            sender.sendMessage("§bGoodBadWorld Winter: " + (enabled ? "§aВКЛЮЧЁН" : "§cВЫКЛЮЧЕН"));
            sender.sendMessage("§7Команды: /winter on, /winter off, /winter reload");
            return true;
        }
        switch (args[0].toLowerCase()) {
            case "on" -> {
                startWinter();
                sender.sendMessage("§b❄ Зимняя атмосфера включена!");
            }
            case "off" -> {
                enabled = false;
                stopSnowTask();
                sender.sendMessage("§7Снегопад и эффекты выключены. Погода в мирах оставлена как есть.");
            }
            case "reload" -> {
                reloadConfig();
                enabled = getConfig().getBoolean("winter.enabled", true);
                if (enabled) startWinter(); else stopSnowTask();
                sender.sendMessage("§aКонфигурация GoodBadWorld Winter перезагружена.");
            }
            default -> sender.sendMessage("§cИспользование: /winter <on|off|reload|status>");
        }
        return true;
    }
}
